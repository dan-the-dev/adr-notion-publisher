<?php

namespace Minicli;

interface ServiceInterface
{
    public function load(App $app);
}
