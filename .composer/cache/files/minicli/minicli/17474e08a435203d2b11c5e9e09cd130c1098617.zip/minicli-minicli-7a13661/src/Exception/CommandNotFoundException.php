<?php

namespace Minicli\Exception;

class CommandNotFoundException extends \Exception
{
}
