<?php


namespace Minicli\Output;

interface PrinterAdapterInterface
{
    public function out($message);
}
